package sdu.zrz.controller;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sdu.zrz.mapper.StudentMapper;
import sdu.zrz.mapper.UserMapper;
import sdu.zrz.pojo.Student;
import sdu.zrz.pojo.User;

import java.util.HashMap;
import java.util.List;

@RestController //能够让类被组件扫描功能发现;控制器中所有的处理器方法的返回值都要直接写入响应体中
@CrossOrigin(origins = {"*", "null"})//实现跨域资源共享，*即任何都可响应
public class Controller {
    @Autowired  //将容器的Bean与需要这个Bean的类组装在一起，完成自动装配
    private StudentMapper studentMapper; //关联类和接口
    @Autowired
    private UserMapper userMapper;
    private Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();

    @GetMapping("/students")
    public String getStudents() {    //查
        List<Student> students = studentMapper.selectList(null);
        for(Student student:students){
            if ((Boolean)student.getSex()){
                student.setSex("男");
            }else {
                student.setSex("女");
            }
        }
        return gson.toJson(students);
    }

    //增删改都是Post方法
    @PostMapping("/add")
    public void addStudent(@RequestBody Student student) {   //@RequestBody 转成JSON格式
        if ((student.getSex()).equals("男")){
            student.setSex(true);
        }else {
            student.setSex(false);
        }
        studentMapper.insert(student);
    }

    @PostMapping("/delete")
    public void deleteStudent(@RequestBody Student student) {
        studentMapper.deleteById(student);
    }

    @PostMapping("/update")
    public void updateStudent(@RequestBody Student student) {
        if (((String)student.getSex()).equals("男")){
            student.setSex(true);
        }else {
            student.setSex(false);
        }
        studentMapper.updateById(student);
    }
    @PostMapping("/login")
    public String loginStudent(@RequestBody User user){
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<User>();
        userQueryWrapper.setEntity(user);
        User user_selected = userMapper.selectOne(userQueryWrapper);//从数据库查一条数据
        if(user_selected == null){
            return "0";
        }
        return "1";
    }
    @PostMapping("/register")
    public void registerUser(@RequestBody User user){
        userMapper.insert(user);
    }

    @PostMapping("/search")
    public String searchStudent(@RequestBody HashMap<String,String> data){
        String name = data.get("name");
        QueryWrapper<Student> studentQueryWrapper = new QueryWrapper<>();
        studentQueryWrapper.like("name",name);
        List<Student> students = studentMapper.selectList(studentQueryWrapper);
        for(Student student:students){
            if ((Boolean)student.getSex()){
                student.setSex("男");
            }else {
                student.setSex("女");
            }
        }
        return gson.toJson(students);
    }
    }

//实体类
package sdu.zrz.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Date;

@Data
//生成方法
public class Student {
    private String id;

    public void setSex(Object sex) {
        this.sex = sex;
    }

    public Object getSex() {
        return sex;
    }

    private String name;
    private Object sex;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date birthday;

    private int admission;
    private float program;
    private float web;
}

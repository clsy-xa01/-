package sdu.zrz;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication    //用来把启动类注入到容器中
@MapperScan("sdu.zrz.mapper")   //包下面的所有接口在编译之后都会生成相应的实现类
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}

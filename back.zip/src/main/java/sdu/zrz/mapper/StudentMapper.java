package sdu.zrz.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import sdu.zrz.pojo.Student;

//BaseMapper简化，默认提供方法
public interface StudentMapper extends BaseMapper<Student> {

}

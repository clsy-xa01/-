package sdu.zrz.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import sdu.zrz.pojo.User;

public interface UserMapper extends BaseMapper<User> {
}
